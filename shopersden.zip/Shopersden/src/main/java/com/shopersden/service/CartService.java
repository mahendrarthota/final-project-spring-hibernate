package com.shopersden.service;

import com.shopersden.models.Cart;

public interface CartService {

	Cart getCartByCartId(String CartId);
}
