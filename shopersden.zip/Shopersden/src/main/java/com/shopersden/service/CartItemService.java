package com.shopersden.service;

import com.shopersden.models.Cart;
import com.shopersden.models.CartItem;

public interface CartItemService {

	void addCartItem(CartItem cartItem);
	void removeCartItem(String CartItemId);
	void removeAllCartItems(Cart cart);
}
