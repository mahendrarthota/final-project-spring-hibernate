package com.shopersden.dao;

import com.shopersden.models.CustomerOrder;

public interface CustomerOrderDao {

	void addCustomerOrder(CustomerOrder customerOrder);
}
