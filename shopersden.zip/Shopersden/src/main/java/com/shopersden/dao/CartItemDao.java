package com.shopersden.dao;

import com.shopersden.models.Cart;
import com.shopersden.models.CartItem;

public interface CartItemDao {

	void addCartItem(CartItem cartItem);
	void removeCartItem(String CartItemId);
	void removeAllCartItems(Cart cart);

}
