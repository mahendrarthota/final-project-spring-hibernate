package com.shopersden.dao;

import com.shopersden.models.Queries;

public interface QueriesDao {

 	void addQuery(Queries queries);
}
