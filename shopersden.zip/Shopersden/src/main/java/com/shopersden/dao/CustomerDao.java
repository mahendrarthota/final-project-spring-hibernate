package com.shopersden.dao;

import java.util.List;

import com.shopersden.models.Customer;

public interface CustomerDao {

	void addCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer getCustomerByemailId(String emailId);

}
