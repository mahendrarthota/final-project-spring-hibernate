package com.shopersden.service;

import com.shopersden.models.Queries;

public interface QueriesService {

	void addQuery(Queries queries);
}
